<style>
    .box{
        border-style: solid;
        border-radius: 10px;
        padding: 5%;
        margin-left: 25%    ;
        margin-right: 25%;
        text-align: center;
        border-color: black;
    }
</style>
<div class="box">

    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\dawic\Documents\projekt\example-app\resources\views/components/box.blade.php ENDPATH**/ ?>