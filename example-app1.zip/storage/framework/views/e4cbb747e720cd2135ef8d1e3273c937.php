<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        header{
            width: 100%;
            height: 10%;
        }
        h3{
            float: right;
        }
    </style>
    <title>Document</title>
</head>
<body>
<header>
    <h3><a href="/logowanie">Zaloguj sie</a></h3>
</header>
<h1>Sklep</h1>

<?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\Users\dawic\Documents\projekt\example-app\resources\views/Components/layout.blade.php ENDPATH**/ ?>