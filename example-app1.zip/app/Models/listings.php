<?php

namespace App\Models;
class Listing {
    
}
