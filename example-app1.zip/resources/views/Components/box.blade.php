<style>
    .box{
        border-style: solid;
        border-radius: 10px;
        padding: 5%;
        margin-left: 25%    ;
        margin-right: 25%;
        text-align: center;
        border-color: black;
    }
</style>
<div class="box">

    {{$slot}}
</div>
